import type { Metadata } from 'next';
import './globals.css';

export const metadata: Metadata = {
  title: 'AI Career Counsellor — Intelligent Career Guidance for India',
  description: 'Discover your dream career with AI-powered guidance. Scientific assessments, personalized roadmaps, and expert career counselling for the Indian job market.',
  keywords: ['career counselling', 'career guidance', 'AI career coach', 'India jobs', 'RIASEC', 'MBTI', 'career assessment'],
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="en">
      <body className="min-h-screen bg-white">{children}</body>
    </html>
  );
}
