'use client';

import { useStore } from '@/lib/store';
import LandingPage from '@/components/sections/LandingPage';
import OnboardingPage from '@/components/sections/OnboardingPage';
import Dashboard from '@/components/sections/Dashboard';
import RIASECAssessment from '@/components/sections/RIASECAssessment';
import MBTIAssessment from '@/components/sections/MBTIAssessment';
import CareerQuiz from '@/components/sections/CareerQuiz';
import ChatCoach from '@/components/sections/ChatCoach';
import CareerPathPage from '@/components/sections/CareerPathPage';
import ResumeBuilder from '@/components/sections/ResumeBuilder';
import MarketInsights from '@/components/sections/MarketInsights';
import ProfileSection from '@/components/sections/ProfileSection';
import Sidebar from '@/components/layout/Sidebar';
import MobileNav from '@/components/layout/MobileNav';
import { Loader2 } from 'lucide-react';

export default function Home() {
  const { isAuthenticated, onboardingComplete, currentSection, _hydrated } = useStore();

  // Show loading while hydrating
  if (!_hydrated) {
    return (
      <div className="flex h-screen items-center justify-center bg-white">
        <div className="text-center">
          <div className="mx-auto mb-4 flex h-12 w-12 items-center justify-center rounded-xl bg-violet-600">
            <Loader2 className="h-6 w-6 animate-spin text-white" />
          </div>
          <p className="text-sm text-gray-500">Loading CareerAI...</p>
        </div>
      </div>
    );
  }

  // Not authenticated → Landing page
  if (!isAuthenticated) {
    return <LandingPage />;
  }

  // Onboarding not complete → Onboarding page
  if (!onboardingComplete) {
    return <OnboardingPage />;
  }

  // Authenticated + Onboarded → App layout with sidebar
  const renderSection = () => {
    switch (currentSection) {
      case 'dashboard': return <Dashboard />;
      case 'riasec': return <RIASECAssessment />;
      case 'mbti': return <MBTIAssessment />;
      case 'career-quiz': return <CareerQuiz />;
      case 'chat': return <ChatCoach />;
      case 'career-path': return <CareerPathPage />;
      case 'resume': return <ResumeBuilder />;
      case 'insights': return <MarketInsights />;
      case 'profile': return <ProfileSection />;
      default: return <Dashboard />;
    }
  };

  return (
    <div className="flex min-h-screen bg-gray-50">
      {/* Desktop Sidebar */}
      <Sidebar />

      {/* Main Content */}
      <main className="flex-1 pb-16 lg:pb-0 lg:ml-64">
        <div className="mx-auto max-w-5xl p-4 lg:p-8">
          {renderSection()}
        </div>
      </main>

      {/* Mobile Bottom Nav */}
      <MobileNav />
    </div>
  );
}
