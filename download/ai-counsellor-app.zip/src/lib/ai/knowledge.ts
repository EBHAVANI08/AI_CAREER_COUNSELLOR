// ===== Career Intelligence Knowledge Base for Indian Market =====

export const entranceExams = {
  engineering: [
    { name: 'JEE Main', fullForm: 'Joint Entrance Examination Main', conductingBody: 'NTA', frequency: 'Twice a year', eligibility: 'Class 12 PCM', website: 'jeemain.nta.nic.in' },
    { name: 'JEE Advanced', fullForm: 'Joint Entrance Examination Advanced', conductingBody: 'IITs (rotational)', frequency: 'Once a year', eligibility: 'JEE Main qualifiers', website: 'jeeadv.ac.in' },
    { name: 'BITSAT', fullForm: 'Birla Institute of Technology and Science Admission Test', conductingBody: 'BITS Pilani', frequency: 'Twice a year', eligibility: 'Class 12 PCM', website: 'bitsadmission.com' },
    { name: 'VITEEE', fullForm: 'VIT Engineering Entrance Exam', conductingBody: 'VIT University', frequency: 'Once a year', eligibility: 'Class 12 PCM', website: 'vit.ac.in' },
    { name: 'SRMJEEE', fullForm: 'SRM Joint Engineering Entrance Exam', conductingBody: 'SRM University', frequency: 'Once a year', eligibility: 'Class 12 PCM', website: 'srmist.edu.in' },
    { name: 'COMEDK', fullForm: 'Consortium of Medical, Engineering and Dental Colleges of Karnataka', conductingBody: 'COMEDK', frequency: 'Once a year', eligibility: 'Class 12 PCM', website: 'comedk.org' },
    { name: 'WBJEE', fullForm: 'West Bengal Joint Entrance Exam', conductingBody: 'WBJEEB', frequency: 'Once a year', eligibility: 'Class 12 PCM', website: 'wbjeeb.nic.in' },
    { name: 'MHT CET', fullForm: 'Maharashtra Common Entrance Test', conductingBody: 'State CET Cell, Maharashtra', frequency: 'Once a year', eligibility: 'Class 12 PCM', website: 'cetcell.mahacet.org' },
  ],
  medical: [
    { name: 'NEET UG', fullForm: 'National Eligibility cum Entrance Test (Undergraduate)', conductingBody: 'NTA', frequency: 'Once a year', eligibility: 'Class 12 PCB', website: 'neet.nta.nic.in' },
    { name: 'AIIMS Nursing', fullForm: 'AIIMS Nursing Entrance Exam', conductingBody: 'AIIMS', frequency: 'Once a year', eligibility: 'Class 12 PCB', website: 'aiimsexams.ac.in' },
    { name: 'JIPMER', fullForm: 'Jawaharlal Institute PG Medical Exam', conductingBody: 'JIPMER', frequency: 'Once a year', eligibility: 'NEET qualified', website: 'jipmer.edu.in' },
  ],
  management: [
    { name: 'CAT', fullForm: 'Common Admission Test', conductingBody: 'IIMs (rotational)', frequency: 'Once a year', eligibility: 'Graduation (50%)', website: 'iimcat.ac.in' },
    { name: 'XAT', fullForm: 'Xavier Aptitude Test', conductingBody: 'XLRI Jamshedpur', frequency: 'Once a year', eligibility: 'Graduation', website: 'xatonline.in' },
    { name: 'MAT', fullForm: 'Management Aptitude Test', conductingBody: 'AIMA', frequency: '4 times a year', eligibility: 'Graduation', website: 'mat.aima.in' },
    { name: 'CMAT', fullForm: 'Common Management Admission Test', conductingBody: 'NTA', frequency: 'Once a year', eligibility: 'Graduation', website: 'cmat.nta.nic.in' },
    { name: 'SNAP', fullForm: 'Symbiosis National Aptitude Test', conductingBody: 'Symbiosis International University', frequency: 'Once a year', eligibility: 'Graduation', website: 'snaptest.org' },
    { name: 'NMAT', fullForm: 'NMIMS Management Aptitude Test', conductingBody: 'GMAC', frequency: 'Once a year', eligibility: 'Graduation (50%)', website: 'nmat.org.in' },
    { name: 'IIFT', fullForm: 'Indian Institute of Foreign Trade Exam', conductingBody: 'IIFT', frequency: 'Once a year', eligibility: 'Graduation', website: 'iift.edu.in' },
  ],
  law: [
    { name: 'CLAT', fullForm: 'Common Law Admission Test', conductingBody: 'Consortium of NLUs', frequency: 'Once a year', eligibility: 'Class 12 (UG) / Graduation (PG)', website: 'consortiumofnlus.ac.in' },
    { name: 'AILET', fullForm: 'All India Law Entrance Test', conductingBody: 'NLU Delhi', frequency: 'Once a year', eligibility: 'Class 12 (UG) / Graduation (PG)', website: 'nludelhi.ac.in' },
    { name: 'LSAT India', fullForm: 'Law School Admission Test India', conductingBody: 'LSAC', frequency: 'Once a year', eligibility: 'Class 12 (UG) / Graduation (PG)', website: 'lsat.org.in' },
  ],
  design: [
    { name: 'NID DAT', fullForm: 'National Institute of Design Design Aptitude Test', conductingBody: 'NID', frequency: 'Once a year', eligibility: 'Class 12 / Graduation', website: 'admissions.nid.edu' },
    { name: 'UCEED', fullForm: 'Undergraduate Common Entrance Exam for Design', conductingBody: 'IIT Bombay', frequency: 'Once a year', eligibility: 'Class 12', website: 'uceed.iitb.ac.in' },
    { name: 'CEED', fullForm: 'Common Entrance Exam for Design', conductingBody: 'IIT Bombay', frequency: 'Once a year', eligibility: 'Graduation', website: 'ceed.iitb.ac.in' },
    { name: 'NIFT Entrance', fullForm: 'National Institute of Fashion Technology Entrance', conductingBody: 'NIFT', frequency: 'Once a year', eligibility: 'Class 12', website: 'nift.ac.in' },
  ],
  civilServices: [
    { name: 'UPSC CSE', fullForm: 'Union Public Service Commission Civil Services Examination', conductingBody: 'UPSC', frequency: 'Once a year', eligibility: 'Graduation', website: 'upsc.gov.in' },
    { name: 'UPSC CDS', fullForm: 'Combined Defence Services Examination', conductingBody: 'UPSC', frequency: 'Twice a year', eligibility: 'Graduation', website: 'upsc.gov.in' },
    { name: 'SSC CGL', fullForm: 'Staff Selection Commission Combined Graduate Level', conductingBody: 'SSC', frequency: 'Once a year', eligibility: 'Graduation', website: 'ssc.nic.in' },
    { name: 'State PSC', fullForm: 'State Public Service Commission Exams', conductingBody: 'State PSCs', frequency: 'Varies', eligibility: 'Graduation', website: 'varies' },
  ],
  general: [
    { name: 'GATE', fullForm: 'Graduate Aptitude Test in Engineering', conductingBody: 'IISc/IITs', frequency: 'Once a year', eligibility: 'B.E./B.Tech/M.Sc', website: 'gate.iitk.ac.in' },
    { name: 'GRE', fullForm: 'Graduate Record Examination', conductingBody: 'ETS', frequency: 'Multiple times', eligibility: 'Graduation', website: 'ets.org/gre' },
    { name: 'GMAT', fullForm: 'Graduate Management Admission Test', conductingBody: 'GMAC', frequency: 'Multiple times', eligibility: 'Graduation', website: 'mba.com' },
    { name: 'IELTS', fullForm: 'International English Language Testing System', conductingBody: 'British Council/IDP', frequency: 'Multiple times', eligibility: 'No minimum', website: 'ielts.org' },
    { name: 'TOEFL', fullForm: 'Test of English as a Foreign Language', conductingBody: 'ETS', frequency: 'Multiple times', eligibility: 'No minimum', website: 'ets.org/toefl' },
  ],
};

export const topInstitutions = {
  engineering: [
    { name: 'IIT Bombay', nirf: 1, avgPackage: '21.7 LPA', location: 'Mumbai', type: 'Government' },
    { name: 'IIT Delhi', nirf: 2, avgPackage: '20.5 LPA', location: 'New Delhi', type: 'Government' },
    { name: 'IIT Madras', nirf: 3, avgPackage: '19.8 LPA', location: 'Chennai', type: 'Government' },
    { name: 'IIT Kanpur', nirf: 4, avgPackage: '18.5 LPA', location: 'Kanpur', type: 'Government' },
    { name: 'IIT Kharagpur', nirf: 5, avgPackage: '18.2 LPA', location: 'Kharagpur', type: 'Government' },
    { name: 'IIT Roorkee', nirf: 6, avgPackage: '17.8 LPA', location: 'Roorkee', type: 'Government' },
    { name: 'NIT Trichy', nirf: 9, avgPackage: '12.5 LPA', location: 'Tiruchirappalli', type: 'Government' },
    { name: 'BITS Pilani', nirf: 11, avgPackage: '16.2 LPA', location: 'Pilani', type: 'Private' },
    { name: 'VIT Vellore', nirf: 12, avgPackage: '8.5 LPA', location: 'Vellore', type: 'Private' },
    { name: 'IIIT Hyderabad', nirf: 14, avgPackage: '22.0 LPA', location: 'Hyderabad', type: 'Government' },
  ],
  management: [
    { name: 'IIM Ahmedabad', nirf: 1, avgPackage: '35.5 LPA', location: 'Ahmedabad', type: 'Government' },
    { name: 'IIM Bangalore', nirf: 2, avgPackage: '33.8 LPA', location: 'Bangalore', type: 'Government' },
    { name: 'IIM Calcutta', nirf: 3, avgPackage: '32.5 LPA', location: 'Kolkata', type: 'Government' },
    { name: 'ISB Hyderabad', nirf: 5, avgPackage: '38.0 LPA', location: 'Hyderabad', type: 'Private' },
    { name: 'XLRI Jamshedpur', nirf: 6, avgPackage: '28.5 LPA', location: 'Jamshedpur', type: 'Private' },
    { name: 'FMS Delhi', nirf: 8, avgPackage: '30.2 LPA', location: 'New Delhi', type: 'Government' },
  ],
  medical: [
    { name: 'AIIMS New Delhi', nirf: 1, avgPackage: 'N/A (Govt)', location: 'New Delhi', type: 'Government' },
    { name: 'PGIMER Chandigarh', nirf: 2, avgPackage: 'N/A (Govt)', location: 'Chandigarh', type: 'Government' },
    { name: 'CMC Vellore', nirf: 3, avgPackage: 'N/A (Govt)', location: 'Vellore', type: 'Private' },
    { name: 'JIPMER Puducherry', nirf: 5, avgPackage: 'N/A (Govt)', location: 'Puducherry', type: 'Government' },
    { name: 'MAMC Delhi', nirf: 8, avgPackage: 'N/A (Govt)', location: 'New Delhi', type: 'Government' },
  ],
};

export const careerFields: Record<string, {
  name: string;
  growthPercent: number;
  demandLevel: 'Very High' | 'High' | 'Medium' | 'Growing';
  salaryRanges: { entry: string; mid: string; senior: string };
  topCompanies: string[];
  keySkills: string[];
  hotRoles: string[];
}> = {
  technology: {
    name: 'Software & IT',
    growthPercent: 25,
    demandLevel: 'Very High',
    salaryRanges: { entry: '4-8 LPA', mid: '10-25 LPA', senior: '30-80 LPA' },
    topCompanies: ['TCS', 'Infosys', 'Wipro', 'Google India', 'Microsoft India', 'Amazon India', 'Flipkart', 'Razorpay'],
    keySkills: ['Programming', 'Cloud Computing', 'DevOps', 'System Design', 'Data Structures'],
    hotRoles: ['Full Stack Developer', 'Backend Engineer', 'Cloud Architect', 'DevOps Engineer', 'Tech Lead'],
  },
  ai_ml: {
    name: 'AI & Machine Learning',
    growthPercent: 35,
    demandLevel: 'Very High',
    salaryRanges: { entry: '6-12 LPA', mid: '15-35 LPA', senior: '40-100 LPA' },
    topCompanies: ['Google DeepMind', 'Microsoft Research', 'Amazon Science', 'Flipkart', 'Swiggy', 'Zomato', 'Jio', 'NVIDIA India'],
    keySkills: ['Python', 'TensorFlow/PyTorch', 'NLP', 'Computer Vision', 'MLOps', 'Statistics'],
    hotRoles: ['ML Engineer', 'Data Scientist', 'AI Researcher', 'NLP Engineer', 'MLOps Engineer'],
  },
  product: {
    name: 'Product Management',
    growthPercent: 30,
    demandLevel: 'High',
    salaryRanges: { entry: '8-15 LPA', mid: '18-35 LPA', senior: '40-70 LPA' },
    topCompanies: ['Flipkart', 'Amazon', 'Razorpay', 'CRED', 'Swiggy', 'Zomato', 'Meesho', 'Groww'],
    keySkills: ['Product Strategy', 'Data Analysis', 'User Research', 'Agile', 'Stakeholder Management'],
    hotRoles: ['Product Manager', 'Associate PM', 'Group PM', 'VP Product', 'Chief Product Officer'],
  },
  design: {
    name: 'UX/UI Design',
    growthPercent: 22,
    demandLevel: 'High',
    salaryRanges: { entry: '4-9 LPA', mid: '10-22 LPA', senior: '25-50 LPA' },
    topCompanies: ['Google India', 'Microsoft', 'Flipkart', 'Swiggy', 'Zomato', 'Razorpay', 'Infosys', 'TCS'],
    keySkills: ['Figma', 'User Research', 'Prototyping', 'Design Systems', 'Interaction Design'],
    hotRoles: ['UX Designer', 'UI Designer', 'Product Designer', 'Design Lead', 'UX Researcher'],
  },
  finance: {
    name: 'Finance & Fintech',
    growthPercent: 20,
    demandLevel: 'High',
    salaryRanges: { entry: '5-10 LPA', mid: '12-28 LPA', senior: '30-60 LPA' },
    topCompanies: ['HDFC Bank', 'ICICI Bank', 'Razorpay', 'PhonePe', 'Paytm', 'Groww', 'Zerodha', 'Goldman Sachs India'],
    keySkills: ['Financial Modeling', 'Risk Analysis', 'SQL', 'Python', 'Regulatory Knowledge'],
    hotRoles: ['Financial Analyst', 'Risk Manager', 'Fintech Engineer', 'Investment Analyst', 'Compliance Officer'],
  },
  healthcare: {
    name: 'Healthcare & Biotech',
    growthPercent: 18,
    demandLevel: 'High',
    salaryRanges: { entry: '5-9 LPA', mid: '10-22 LPA', senior: '25-50 LPA' },
    topCompanies: ['Biocon', 'Dr. Reddys', 'Sun Pharma', 'Cipla', 'Apollo Hospitals', 'Fortis', 'Serum Institute', 'Bharat Biotech'],
    keySkills: ['Clinical Research', 'Biostatistics', 'Regulatory Affairs', 'Lab Techniques', 'Pharmacovigilance'],
    hotRoles: ['Clinical Research Associate', 'Biotech Scientist', 'Medical Writer', 'Regulatory Affairs Specialist', 'Healthcare Consultant'],
  },
};

export const riasecMbtiCombinations: Record<string, {
  title: string;
  description: string;
  careerMatches: string[];
  strengths: string[];
  developmentAreas: string[];
}> = {
  'RI-INTJ': {
    title: 'The Technical Innovator',
    description: 'You combine hands-on problem-solving with strategic vision. Your investigative nature drives you to understand systems deeply while your practical side ensures solutions work in the real world.',
    careerMatches: ['Mechanical Engineer', 'Systems Architect', 'Robotics Engineer', 'R&D Director'],
    strengths: ['Deep technical knowledge', 'Strategic planning', 'Independent problem-solving'],
    developmentAreas: ['Team collaboration', 'Communication skills', 'Adapting to ambiguity'],
  },
  'IA-INFP': {
    title: 'The Creative Researcher',
    description: 'Your investigative curiosity is fueled by deep personal values and creativity. You seek meaning in your work and are drawn to research that makes a difference.',
    careerMatches: ['Research Scientist', 'UX Researcher', 'Data Journalist', 'Environmental Scientist'],
    strengths: ['Deep empathy', 'Creative problem-solving', 'Meaning-driven motivation'],
    developmentAreas: ['Time management', 'Handling criticism', 'Decision-making under pressure'],
  },
  'AS-ENFJ': {
    title: 'The Inspiring Educator',
    description: 'You combine artistic expression with a desire to help others grow. Your natural leadership and creativity make you exceptional at inspiring and educating.',
    careerMatches: ['Art Therapist', 'Creative Director (EdTech)', 'Curriculum Designer', 'Cultural Program Manager'],
    strengths: ['Inspiring leadership', 'Creative communication', 'Deep empathy'],
    developmentAreas: ['Setting boundaries', 'Objective decision-making', 'Self-care'],
  },
  'SE-ESTJ': {
    title: 'The Business Leader',
    description: 'Your social intelligence and enterprising drive make you a natural leader. You excel at organizing people and resources toward ambitious goals.',
    careerMatches: ['Business Development Head', 'Sales Director', 'HR Director', 'Operations Manager'],
    strengths: ['People management', 'Goal-oriented execution', 'Organizational skills'],
    developmentAreas: ['Flexibility', 'Creative thinking', 'Patience with process'],
  },
  'EC-ISTJ': {
    title: 'The Corporate Strategist',
    description: 'You blend enterprising vision with conventional precision. Your strategic mind works within systems to achieve measurable business outcomes.',
    careerMatches: ['Financial Controller', 'Compliance Manager', 'Operations Head', 'Business Analyst'],
    strengths: ['Strategic planning', 'Attention to detail', 'Reliability'],
    developmentAreas: ['Adaptability', 'Innovation', 'Emotional intelligence'],
  },
  'IC-INTP': {
    title: 'The Analytical Architect',
    description: 'Your investigative depth and conventional precision make you exceptional at designing complex systems. You see patterns others miss and build frameworks that last.',
    careerMatches: ['Data Architect', 'Software Architect', 'Quantitative Analyst', 'Research Engineer'],
    strengths: ['Logical analysis', 'Pattern recognition', 'System design'],
    developmentAreas: ['Communication', 'Time management', 'Collaboration'],
  },
  'AE-ENTP': {
    title: 'The Creative Entrepreneur',
    description: 'Your artistic vision paired with enterprising drive makes you a startup founder at heart. You see opportunities where others see obstacles and create something from nothing.',
    careerMatches: ['Startup Founder', 'Creative Agency Owner', 'Product Innovator', 'Venture Capital Analyst'],
    strengths: ['Innovation', 'Persuasion', 'Visionary thinking'],
    developmentAreas: ['Follow-through', 'Financial planning', 'Attention to detail'],
  },
  'SI-INFJ': {
    title: 'The Insightful Healer',
    description: 'Your social nature combined with investigative depth allows you to deeply understand and help people. You are drawn to careers that combine service with intellectual depth.',
    careerMatches: ['Clinical Psychologist', 'Counselor', 'Social Worker', 'Healthcare Administrator'],
    strengths: ['Deep understanding of people', 'Insightful analysis', 'Compassionate service'],
    developmentAreas: ['Self-advocacy', 'Setting boundaries', 'Handling conflict'],
  },
  'RE-ESTP': {
    title: 'The Action Executive',
    description: 'You combine hands-on capability with enterprising energy. You thrive in fast-paced environments where you can make quick decisions and see immediate results.',
    careerMatches: ['Sales Engineer', 'Operations Executive', 'Project Manager', 'Entrepreneur'],
    strengths: ['Quick decision-making', 'Hands-on execution', 'Adaptability'],
    developmentAreas: ['Long-term planning', 'Patience', 'Delegation'],
  },
  'AC-ISFP': {
    title: 'The Precision Artist',
    description: 'Your artistic sensibility meets conventional detail-orientation. You create beautiful, structured work and excel in roles that demand both creativity and accuracy.',
    careerMatches: ['Graphic Designer', 'Architect', 'Fashion Designer', 'Interior Designer'],
    strengths: ['Aesthetic sense', 'Attention to detail', 'Craftsmanship'],
    developmentAreas: ['Self-promotion', 'Handling criticism', 'Networking'],
  },
  'IE-ENTJ': {
    title: 'The Research Executive',
    description: 'Your investigative mind and enterprising ambition drive you to lead research-driven organizations. You turn knowledge into strategy and strategy into results.',
    careerMatches: ['Chief Technology Officer', 'R&D Director', 'Strategy Consultant', 'Biotech CEO'],
    strengths: ['Strategic vision', 'Analytical depth', 'Leadership'],
    developmentAreas: ['Patience with process', 'Emotional intelligence', 'Work-life balance'],
  },
  'SC-ESFJ': {
    title: 'The Community Organizer',
    description: 'Your social warmth and conventional reliability make you the backbone of any community. You ensure systems serve people effectively.',
    careerMatches: ['School Administrator', 'Healthcare Manager', 'Community Program Director', 'Event Manager'],
    strengths: ['People skills', 'Organization', 'Reliability'],
    developmentAreas: ['Innovation', 'Handling change', 'Delegation'],
  },
  'RA-ISTP': {
    title: 'The Practical Creator',
    description: 'You blend hands-on skill with artistic vision. You work best when you can design and build tangible solutions, from products to prototypes.',
    careerMatches: ['Industrial Designer', 'Mechanical Designer', 'Product Engineer', 'Artisan Entrepreneur'],
    strengths: ['Hands-on skill', 'Creative problem-solving', 'Independence'],
    developmentAreas: ['Communication', 'Team collaboration', 'Planning'],
  },
  'IS-ISTJ': {
    title: 'The Methodical Researcher',
    description: 'Your investigative nature is grounded by systematic, reliable methods. You excel at research that requires patience, precision, and thorough documentation.',
    careerMatches: ['Lab Researcher', 'Quality Analyst', 'Forensic Scientist', 'Academic Researcher'],
    strengths: ['Methodical approach', 'Thoroughness', 'Reliability'],
    developmentAreas: ['Speed', 'Creative thinking', 'Adaptability'],
  },
  'EA-ENFP': {
    title: 'The Visionary Leader',
    description: 'Your enterprising energy and artistic creativity make you a charismatic leader who inspires through vision and innovation. You see possibilities everywhere.',
    careerMatches: ['Creative Director', 'Marketing Director', 'Startup CEO', 'Brand Strategist'],
    strengths: ['Vision', 'Charisma', 'Creative problem-solving'],
    developmentAreas: ['Focus', 'Detail management', 'Follow-through'],
  },
  'RC-ESTJ': {
    title: 'The Systems Manager',
    description: 'Your practical skills and conventional mindset make you exceptional at managing complex systems and operations. You ensure everything runs like clockwork.',
    careerMatches: ['Operations Manager', 'Supply Chain Director', 'Factory Manager', 'Quality Head'],
    strengths: ['Systems thinking', 'Reliability', 'Efficiency'],
    developmentAreas: ['Innovation', 'Flexibility', 'People management'],
  },
};

export const inDemandSkills = [
  { name: 'Artificial Intelligence & ML', demand: 95, trend: 'up' as const, category: 'Tech' },
  { name: 'Cloud Computing (AWS/Azure/GCP)', demand: 92, trend: 'up' as const, category: 'Tech' },
  { name: 'Full Stack Development', demand: 90, trend: 'stable' as const, category: 'Tech' },
  { name: 'Data Science & Analytics', demand: 88, trend: 'up' as const, category: 'Tech' },
  { name: 'Cybersecurity', demand: 87, trend: 'up' as const, category: 'Tech' },
  { name: 'Product Management', demand: 85, trend: 'up' as const, category: 'Business' },
  { name: 'UX/UI Design', demand: 82, trend: 'up' as const, category: 'Design' },
  { name: 'DevOps & SRE', demand: 80, trend: 'up' as const, category: 'Tech' },
  { name: 'Blockchain & Web3', demand: 72, trend: 'up' as const, category: 'Tech' },
  { name: 'Digital Marketing', demand: 78, trend: 'stable' as const, category: 'Business' },
  { name: 'Financial Modeling', demand: 75, trend: 'stable' as const, category: 'Finance' },
  { name: 'Communication & Soft Skills', demand: 85, trend: 'up' as const, category: 'Soft Skills' },
];

export const learningPlatforms = [
  { name: 'Coursera', description: 'University courses from IITs, IIITs & global partners', url: 'coursera.org', focus: ['All fields'], indianContent: true, free: true },
  { name: 'NPTEL', description: 'IIT/IISc lecture series — free Indian MOOCs', url: 'nptel.ac.in', focus: ['Engineering', 'Science', 'Management'], indianContent: true, free: true },
  { name: 'Udemy', description: 'Affordable practical courses on every skill', url: 'udemy.com', focus: ['All fields'], indianContent: false, free: false },
  { name: 'edX', description: 'IIT Bombay, IIM Bangalore & global university courses', url: 'edx.org', focus: ['All fields'], indianContent: true, free: true },
  { name: 'Unacademy', description: 'India-specific exam prep — JEE, NEET, UPSC, CAT', url: 'unacademy.com', focus: ['Exam Prep'], indianContent: true, free: false },
  { name: 'Scaler Academy', description: 'Structured programs for software engineering careers', url: 'scaler.com', focus: ['Software Engineering'], indianContent: true, free: false },
  { name: 'UpGrad', description: 'Online degrees & certifications from Indian universities', url: 'upgrad.com', focus: ['MBA', 'Data Science', 'Tech'], indianContent: true, free: false },
  { name: 'Khan Academy', description: 'Free foundational learning for math, science, economics', url: 'khanacademy.org', focus: ['Foundations'], indianContent: false, free: true },
];
