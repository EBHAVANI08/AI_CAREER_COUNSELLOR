'use client';

import { useStore } from '@/lib/store';
import type { AppSection } from '@/types';
import {
  LayoutDashboard, Target, Brain, BarChart3, MessageSquare,
  Map, FileText, TrendingUp, User, LogOut, Zap,
} from 'lucide-react';

const navItems: { section: AppSection; label: string; icon: any }[] = [
  { section: 'dashboard', label: 'Dashboard', icon: LayoutDashboard },
  { section: 'riasec', label: 'RIASEC', icon: Target },
  { section: 'mbti', label: 'MBTI', icon: Brain },
  { section: 'career-quiz', label: 'Career Quiz', icon: BarChart3 },
  { section: 'chat', label: 'AI Chat', icon: MessageSquare },
  { section: 'career-path', label: 'Career Path', icon: Map },
  { section: 'resume', label: 'Resume', icon: FileText },
  { section: 'insights', label: 'Insights', icon: TrendingUp },
  { section: 'profile', label: 'Profile', icon: User },
];

export default function Sidebar() {
  const { currentSection, navigateTo, logout, user } = useStore();

  return (
    <aside className="hidden lg:flex lg:flex-col lg:w-64 lg:fixed lg:inset-y-0 bg-white border-r border-gray-200">
      {/* Logo */}
      <div className="flex items-center gap-2.5 p-6 border-b border-gray-100">
        <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-violet-600">
          <Zap className="h-5 w-5 text-white" />
        </div>
        <div>
          <span className="text-base font-bold text-gray-900">CareerAI</span>
          <span className="block text-xs text-gray-400">Career Guidance</span>
        </div>
      </div>

      {/* User Info */}
      <div className="px-4 py-3 border-b border-gray-100">
        <div className="flex items-center gap-3 px-3 py-2 rounded-lg bg-gray-50">
          <div className="flex h-8 w-8 items-center justify-center rounded-full bg-violet-100 text-sm font-bold text-violet-600">
            {user?.name?.charAt(0)?.toUpperCase() || 'U'}
          </div>
          <div className="min-w-0">
            <p className="text-sm font-medium text-gray-900 truncate">{user?.name || 'User'}</p>
            <p className="text-xs text-gray-400 truncate">{user?.email || ''}</p>
          </div>
        </div>
      </div>

      {/* Navigation */}
      <nav className="flex-1 overflow-y-auto custom-scroll px-3 py-4 space-y-1">
        {navItems.map((item) => {
          const isActive = currentSection === item.section;
          return (
            <button
              key={item.section}
              onClick={() => navigateTo(item.section)}
              className={`w-full flex items-center gap-3 rounded-lg px-3 py-2.5 text-sm font-medium transition-all ${
                isActive
                  ? 'bg-violet-100 text-violet-700'
                  : 'text-gray-600 hover:bg-gray-50 hover:text-gray-900'
              }`}
            >
              <item.icon className={`h-5 w-5 ${isActive ? 'text-violet-600' : 'text-gray-400'}`} />
              {item.label}
              {isActive && (
                <div className="ml-auto h-1.5 w-1.5 rounded-full bg-violet-500" />
              )}
            </button>
          );
        })}
      </nav>

      {/* Logout */}
      <div className="border-t border-gray-100 p-4">
        <button
          onClick={logout}
          className="w-full flex items-center gap-3 rounded-lg px-3 py-2.5 text-sm font-medium text-gray-500 hover:bg-red-50 hover:text-red-600 transition-all"
        >
          <LogOut className="h-5 w-5" />
          Sign Out
        </button>
      </div>
    </aside>
  );
}
