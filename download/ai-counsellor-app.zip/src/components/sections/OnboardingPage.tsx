'use client';

import { useStore } from '@/lib/store';
import { GraduationCap, Briefcase, ArrowRight } from 'lucide-react';

export default function OnboardingPage() {
  const { user, setUserType, completeOnboarding } = useStore();

  const handleSelect = (type: 'school' | 'college') => {
    setUserType(type);
    completeOnboarding();
  };

  return (
    <div className="flex min-h-screen items-center justify-center bg-gradient-to-br from-violet-50 via-white to-purple-50 p-6">
      <div className="w-full max-w-2xl space-y-8">
        {/* Header */}
        <div className="text-center space-y-3">
          <div className="inline-flex items-center gap-2 ai-badge text-sm">
            ✨ Let&apos;s get started
          </div>
          <h1 className="text-3xl font-bold text-gray-900">
            Welcome, {user?.name || 'there'}!
          </h1>
          <p className="text-gray-500 max-w-md mx-auto">
            Tell us where you are in your journey so we can personalize your career guidance experience.
          </p>
        </div>

        {/* Selection Cards */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
          {/* School Student Card */}
          <button
            onClick={() => handleSelect('school')}
            className="group relative flex flex-col items-center text-center rounded-2xl border-2 border-gray-200 bg-white p-8 shadow-sm transition-all duration-300 hover:border-violet-400 hover:shadow-lg hover:shadow-violet-100"
          >
            <div className="mb-5 flex h-16 w-16 items-center justify-center rounded-2xl bg-violet-100 text-violet-600 transition-colors group-hover:bg-violet-600 group-hover:text-white">
              <GraduationCap className="h-8 w-8" />
            </div>
            <h3 className="text-xl font-bold text-gray-900 mb-2">School Student</h3>
            <p className="text-sm text-gray-500 mb-4">
              Preparing for entrance exams like JEE, NEET, or exploring career options after Class 10/12
            </p>
            <div className="flex items-center gap-1 text-sm font-semibold text-violet-600 group-hover:gap-2 transition-all">
              Get Started <ArrowRight className="h-4 w-4" />
            </div>
          </button>

          {/* College Graduate Card */}
          <button
            onClick={() => handleSelect('college')}
            className="group relative flex flex-col items-center text-center rounded-2xl border-2 border-gray-200 bg-white p-8 shadow-sm transition-all duration-300 hover:border-violet-400 hover:shadow-lg hover:shadow-violet-100"
          >
            <div className="mb-5 flex h-16 w-16 items-center justify-center rounded-2xl bg-purple-100 text-purple-600 transition-colors group-hover:bg-purple-600 group-hover:text-white">
              <Briefcase className="h-8 w-8" />
            </div>
            <h3 className="text-xl font-bold text-gray-900 mb-2">College Graduate</h3>
            <p className="text-sm text-gray-500 mb-4">
              Looking for jobs, switching careers, or aiming for growth in the Indian job market
            </p>
            <div className="flex items-center gap-1 text-sm font-semibold text-violet-600 group-hover:gap-2 transition-all">
              Get Started <ArrowRight className="h-4 w-4" />
            </div>
          </button>
        </div>

        <p className="text-center text-xs text-gray-400">
          You can change this later in your profile settings
        </p>
      </div>
    </div>
  );
}
