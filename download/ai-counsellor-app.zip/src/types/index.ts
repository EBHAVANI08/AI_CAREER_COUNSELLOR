// ===== AI Career Counsellor — Shared Types =====

export type AppSection =
  | 'landing'
  | 'onboarding'
  | 'dashboard'
  | 'riasec'
  | 'mbti'
  | 'career-quiz'
  | 'chat'
  | 'career-path'
  | 'resume'
  | 'insights'
  | 'profile';

export interface UserProfile {
  name: string;
  email: string;
  userType: 'school' | 'college' | null;
  onboardingComplete: boolean;
  riasecResult: RIASECResult | null;
  mbtiResult: MBTIResult | null;
  careerQuizResult: CareerQuizResult | null;
  skills: string[];
  interests: string[];
  education: string;
  targetRole: string;
}

export interface RIASECResult {
  scores: {
    R: number; // Realistic
    I: number; // Investigative
    A: number; // Artistic
    S: number; // Social
    E: number; // Enterprising
    C: number; // Conventional
  };
  topCode: string;
  topTwoCode: string;
  completedAt: string;
}

export interface MBTIResult {
  dimensions: {
    E: number; I: number; // Extraversion / Introversion
    S: number; N: number; // Sensing / Intuition
    T: number; F: number; // Thinking / Feeling
    J: number; P: number; // Judging / Perceiving
  };
  type: string; // e.g. "INTJ"
  completedAt: string;
}

export interface CareerQuizResult {
  fieldScores: Record<string, number>;
  topFields: { field: string; score: number; matchPercentage: number }[];
  completedAt: string;
}

export interface CareerPathStep {
  id: string;
  title: string;
  description: string;
  timeline: string;
  skills: string[];
  milestones: string[];
  resources: string[];
  completed: boolean;
}

export interface ChatMessage {
  id: string;
  role: 'user' | 'assistant';
  content: string;
  timestamp: string;
  suggestedActions?: SuggestedAction[];
  agentUsed?: string;
}

export interface SuggestedAction {
  id: string;
  label: string;
  section: AppSection;
  description?: string;
}

export interface AIRoutingResult {
  primaryPath: string;
  secondaryPath: string;
  confidence: number;
  reasoning: string;
  recommendedActions: SuggestedAction[];
}

export interface AssessmentAnalysis {
  summary: string;
  strengths: string[];
  careerMatches: string[];
  skillGaps: string[];
  recommendations: string[];
  crossAssessmentInsights: string[];
}
